import { Tool } from "@modelcontextprotocol/server";
import { AdtHttp } from "abap-adt-api";
import { environment } from "../lib/environment";

export class PingHandlers {
  @Tool({
    name: "pingAbapBackend",
    description: "Check SAP ADT connectivity using abap-adt-api",
    type: "object"
  })
  async pingAbapBackend(): Promise<{ success: boolean }> {
    try {
      const adt = new AdtHttp({
        baseURL: environment.SAP_URL,
        auth: {
          user: environment.SAP_USER,
          password: environment.SAP_PASSWORD
        },
        client: environment.SAP_CLIENT,
        language: environment.SAP_LANGUAGE || "EN"
      });

      await adt.ping(); // Sends GET /sap/bc/adt/ping
      return { success: true };
    } catch (err) {
      console.error("pingAbapBackend failed:", err);
      return { success: false };
    }
  }
}
