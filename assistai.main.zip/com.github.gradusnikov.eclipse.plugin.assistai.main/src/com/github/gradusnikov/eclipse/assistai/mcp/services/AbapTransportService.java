package com.github.gradusnikov.eclipse.assistai.mcp.services;

import com.github.gradusnikov.eclipse.assistai.mcp.ToolExecutor;

import java.util.HashMap;
import java.util.Map;

public class AbapTransportService {

    public static Object createTransport(String description) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("description", description);
        return ToolExecutor.getInstance().call("createTransport", payload).join();
    }

    public static Object releaseTransport(String transportNumber) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("transportNumber", transportNumber);
        return ToolExecutor.getInstance().call("transportRelease", payload).join();
    }

    public static Object getTransportInfo(String objectUrl) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("objSourceUrl", objectUrl);
        return ToolExecutor.getInstance().call("transportInfo", payload).join();
    }
}
