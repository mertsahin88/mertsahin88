package com.github.gradusnikov.eclipse.assistai.tools;

public class AbapObjectDetector {

    public static class AbapObjectMetadata {
        public final String objectType;
        public final String objectName;
        public final String sourceCode;

        public AbapObjectMetadata(String objectType, String objectName, String sourceCode) {
            this.objectType = objectType;
            this.objectName = objectName;
            this.sourceCode = sourceCode;
        }
    }

    public static AbapObjectMetadata extractMetadata(String sourceCode) {
        String code = sourceCode.trim().toUpperCase();

        if (code.contains("DEFINE VIEW")) {
            String name = extractWordAfter(code, "DEFINE VIEW");
            return new AbapObjectMetadata("cds_view", name, sourceCode);
        } else if (code.contains("CLASS ZCL_")) {
            String name = extractWordAfter(code, "CLASS");
            return new AbapObjectMetadata("class", name, sourceCode);
        } else if (code.contains("INTERFACE ZIF_")) {
            String name = extractWordAfter(code, "INTERFACE");
            return new AbapObjectMetadata("interface", name, sourceCode);
        } else if (code.contains("FUNCTION Z")) {
            String name = extractWordAfter(code, "FUNCTION");
            return new AbapObjectMetadata("function", name, sourceCode);
        } else if (code.contains("INCLUDE Z")) {
            String name = extractWordAfter(code, "INCLUDE");
            return new AbapObjectMetadata("include", name, sourceCode);
        } else if (code.contains("REPORT Z")) {
            String name = extractWordAfter(code, "REPORT");
            return new AbapObjectMetadata("program", name, sourceCode);
        }

        return new AbapObjectMetadata("unknown", "Z_UNKNOWN", sourceCode);
    }

    private static String extractWordAfter(String source, String keyword) {
        int idx = source.indexOf(keyword);
        if (idx != -1) {
            String[] parts = source.substring(idx + keyword.length()).trim().split("\\s|\\.|\\n");
            if (parts.length > 0) return parts[0].replace(";", "");
        }
        return "Z_UNKNOWN";
    }
}
