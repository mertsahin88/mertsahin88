package com.github.gradusnikov.eclipse.assistai.jobs;

public interface AssistAIJobConstants
{
    public static final String JOB_PREFIX = "AssistAI: ";
}
