package com.github.gradusnikov.eclipse.assistai.mcp.services;

import com.github.gradusnikov.eclipse.assistai.mcp.ToolExecutor;

import java.util.HashMap;
import java.util.Map;

public class AbapCodeAnalysisService {

    public static Object syntaxCheck(String code, String url) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("code", code);
        payload.put("url", url);
        return ToolExecutor.getInstance().call("syntaxCheckCode", payload).join();
    }

    public static Object prettyPrint(String source) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("source", source);
        return ToolExecutor.getInstance().call("prettyPrinter", payload).join();
    }

    public static Object findDefinition(String uri, int line, int column) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("uri", uri);
        payload.put("line", line);
        payload.put("column", column);
        return ToolExecutor.getInstance().call("findDefinition", payload).join();
    }

    public static Object usageReferences(String uri, int line, int column) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("uri", uri);
        payload.put("line", line);
        payload.put("column", column);
        return ToolExecutor.getInstance().call("usageReferences", payload).join();
    }
}
