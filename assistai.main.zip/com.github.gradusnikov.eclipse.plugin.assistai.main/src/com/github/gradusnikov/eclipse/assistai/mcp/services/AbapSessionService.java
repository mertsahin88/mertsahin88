package com.github.gradusnikov.eclipse.assistai.mcp.services;

import com.github.gradusnikov.eclipse.assistai.mcp.ToolExecutor;

import java.util.Map;

public class AbapSessionService {

    public static Object login(String username, String password, String url, String client, String language) {
        Map<String, Object> payload = Map.of(
            "username", username,
            "password", password,
            "url", url,
            "client", client,
            "language", language
        );
        return ToolExecutor.getInstance().call("login", payload).join();
    }

    public static Object logout() {
        return ToolExecutor.getInstance().call("logout", Map.of()).join();
    }

    public static Object dropSession() {
        return ToolExecutor.getInstance().call("dropSession", Map.of()).join();
    }

    public static Object pingAbapBackend() {
        return ToolExecutor.getInstance().call("healthcheck", Map.of()).join();
    }
}
