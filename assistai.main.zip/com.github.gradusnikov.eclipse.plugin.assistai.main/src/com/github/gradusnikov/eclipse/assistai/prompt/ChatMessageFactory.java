package com.github.gradusnikov.eclipse.assistai.prompt;

import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.e4.core.di.annotations.Creatable;

import com.github.gradusnikov.eclipse.assistai.chat.ChatMessage;
import com.github.gradusnikov.eclipse.assistai.repository.PromptRepository;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Creatable
@Singleton
public class ChatMessageFactory {

	@Inject
	private PromptContextValueProvider contextValues;

	@Inject
	private PromptRepository promptRepository;

	public ChatMessageFactory() {
	}

	public ChatMessage createAssistantChatMessage(String text) {
		ChatMessage message = new ChatMessage(UUID.randomUUID().toString(), "assistant");
		message.setContent(text);
		return message;
	}

	public ChatMessage createUserChatMessage(Prompts type) {
		Supplier<String> promptSupplier = switch (type) {
		case DOCUMENT -> abapDocPromptSupplier();
		case TEST_CASE -> unitTestSupplier();
		case CODEREVIEW -> codeReviewPromptSupplier();
		case EXPLAIN -> explainCodePromptSupplier();
		case FIX_ERRORS -> fixErrorsPromptSupplier();
		default -> throw new IllegalArgumentException();
		};
		return createUserChatMessage(promptSupplier);
	}

	public ChatMessage createGenerateGitCommitCommentJob() {
		Supplier<String> promptSupplier = () -> updatePromptText(
				promptRepository.getPrompt(Prompts.GIT_COMMENT.name()));
		return createUserChatMessage(promptSupplier);
	}

	public ChatMessage createUserChatMessage(Supplier<String> promptSupplier) {
		ChatMessage message = new ChatMessage(UUID.randomUUID().toString(), "user");
		message.setContent(promptSupplier.get());
		return message;
	}

	private Supplier<String> fixErrorsPromptSupplier() {
		return () -> updatePromptText(promptRepository.getPrompt(Prompts.FIX_ERRORS.name()));
	}

	private Supplier<String> explainCodePromptSupplier() {
		return () -> updatePromptText(promptRepository.getPrompt(Prompts.EXPLAIN.name()));
	}

	private Supplier<String> abapDocPromptSupplier() {
		return () -> updatePromptText(promptRepository.getPrompt(Prompts.DOCUMENT.name()));
	}

	private Supplier<String> unitTestSupplier() {
		return () -> updatePromptText(promptRepository.getPrompt(Prompts.TEST_CASE.name()));
	}

	private Supplier<String> codeReviewPromptSupplier() {
		return () -> {
			String promptText = promptRepository.getPrompt(Prompts.CODEREVIEW.name());
			return updatePromptText(promptText);
		};
	}

	public String updatePromptText(String promptText) {
		Pattern pattern = Pattern.compile("\\$\\{(\\S+)}");
		Matcher matcher = pattern.matcher(promptText);
		StringBuilder out = new StringBuilder();
		while (matcher.find()) {
			String key = matcher.group(1);
			String replacement = Optional.ofNullable(contextValues.getContextValue(key)).map(Matcher::quoteReplacement)
					.orElse("");
			matcher.appendReplacement(out, replacement);
		}
		matcher.appendTail(out);
		return out.toString();
	}
}
