package com.github.gradusnikov.eclipse.assistai.mcp.services;

import com.github.gradusnikov.eclipse.assistai.mcp.ToolExecutor;

import java.util.HashMap;
import java.util.Map;

public class AbapObjectCreateService {

    public static boolean createAndActivate(String objectType, String objectName, String sourceCode, String packageName, String transport) {
        try {
            ToolExecutor client = ToolExecutor.getInstance();
            String uri = "/sap/bc/adt/oo/" + objectType + "s/" + objectName.toLowerCase();

            // 1. Create Object
            Map<String, Object> createPayload = new HashMap<>();
            createPayload.put("name", objectName);
            createPayload.put("type", objectType);
            createPayload.put("package", packageName);
            createPayload.put("transport", transport);
            client.call("createObject", createPayload).join();

            // 2. Set Source
            Map<String, Object> sourcePayload = new HashMap<>();
            sourcePayload.put("objectSourceUrl", uri + "/source/main");
            sourcePayload.put("source", sourceCode);
            sourcePayload.put("transport", transport);
            client.call("setObjectSource", sourcePayload).join();

            // 3. Syntax Check
            Map<String, Object> checkPayload = new HashMap<>();
            checkPayload.put("code", sourceCode);
            checkPayload.put("url", uri + "/source/main");
            client.call("syntaxCheckCode", checkPayload).join();

            // 4. Activate
            Map<String, Object> activatePayload = new HashMap<>();
            activatePayload.put("objects", new Object[]{
                Map.of("name", objectName, "type", objectType)
            });
            client.call("activateObjects", activatePayload).join();

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean setSource(String source, String uri, String lockHandle, String transport) {
        try {
            ToolExecutor client = ToolExecutor.getInstance();
            Map<String, Object> payload = new HashMap<>();
            payload.put("objectSourceUrl", uri);
            payload.put("source", source);
            payload.put("lockHandle", lockHandle);
            payload.put("transport", transport);
            client.call("setObjectSource", payload).join();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean activate(String objectName, String objectType) {
        try {
            ToolExecutor client = ToolExecutor.getInstance();
            Map<String, Object> payload = new HashMap<>();
            payload.put("objects", new Object[]{
                Map.of("name", objectName, "type", objectType)
            });
            client.call("activateObjects", payload).join();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
