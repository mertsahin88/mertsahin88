package com.github.gradusnikov.eclipse.assistai.mcp.services;

import com.github.gradusnikov.eclipse.assistai.mcp.ToolExecutor;

import java.util.HashMap;
import java.util.Map;

public class AbapUnitTestService {

    public static Object runTests(String objectName) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("object", objectName);
        return ToolExecutor.getInstance().call("unitTestRun", payload).join();
    }

    public static Object evaluateTests(String runId) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("run_id", runId);
        return ToolExecutor.getInstance().call("unitTestEvaluation", payload).join();
    }
}
