package com.github.gradusnikov.eclipse.assistai;

import org.eclipse.e4.core.contexts.ContextInjectionFactory;
import org.eclipse.e4.core.contexts.EclipseContextFactory;
import org.eclipse.e4.core.contexts.IEclipseContext;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import com.github.gradusnikov.eclipse.assistai.preferences.mcp.McpServerPreferencePresenter;
import com.github.gradusnikov.eclipse.assistai.preferences.models.ModelListPreferencePresenter;
import com.github.gradusnikov.eclipse.assistai.preferences.prompts.PromptsPreferencePresenter;
import com.github.gradusnikov.eclipse.assistai.repository.ModelApiDescriptorRepository;
import com.github.gradusnikov.eclipse.assistai.mcp.McpServerDescriptor;
import com.github.gradusnikov.eclipse.assistai.mcp.ToolExecutor;

public class Activator extends AbstractUIPlugin {
    private static Activator plugin = null;

    @Override
    public void start(BundleContext context) throws Exception {
        super.start(context);
        plugin = this;

        try {
            // Load MCP Server Preferences
            McpServerPreferencePresenter presenter = getMCPServerPreferencePresenter();

            presenter.getClientRegistry().findClient("mcp-abap").ifPresent(client -> {
                try {
                    var descriptor = (McpServerDescriptor) presenter.getDescriptor("mcp-abap");

                    boolean hasCredentials = descriptor != null &&
                            descriptor.environmentVariables().stream().allMatch(ev ->
                                    switch (ev.name()) {
                                        case "SAP_URL", "SAP_USER", "SAP_PASSWORD", "SAP_CLIENT" -> ev.value() != null && !ev.value().isBlank();
                                        default -> true;
                                    }
                            );

                    if (!hasCredentials) {
                        System.out.println("[AssistAI] Skipping mcp-abap autostart — SAP credentials incomplete.");
                        return;
                    }

                    client.initialize(); // Starts the MCP server

                    // ✅ Initialize ToolExecutor after client is ready
                    ToolExecutor.initialize(client);

                    System.out.println("[AssistAI] mcp-abap auto-started and ToolExecutor initialized.");
                    /*
                    // Optional: Ping backend
                    client.getClass()
                          .getMethod("call", String.class, Map.class)
                          .invoke(client, "pingAbapBackend", java.util.Map.of());
                    */
                } catch (Exception e) {
                    System.err.println("[AssistAI] Failed to auto-start mcp-abap: " + e.getMessage());
                }
            });

        } catch (Exception e) {
            System.err.println("[AssistAI] MCP auto-start error: " + e.getMessage());
        }
    }

    public static Activator getDefault() {
        return plugin;
    }

    public PromptsPreferencePresenter getPromptsPreferencePresenter() {
        return make(PromptsPreferencePresenter.class);
    }

    public ModelListPreferencePresenter getModelsPreferencePresenter() {
        return make(ModelListPreferencePresenter.class);
    }

    public McpServerPreferencePresenter getMCPServerPreferencePresenter() {
        return make(McpServerPreferencePresenter.class);
    }

    public ModelApiDescriptorRepository getModelApiDescriptorRepository() {
        return make(ModelApiDescriptorRepository.class);
    }

    public <T> T make(Class<T> clazz) {
        IEclipseContext eclipseContext;
        try {
            IWorkbench workbench = PlatformUI.getWorkbench();
            eclipseContext = workbench.getService(IEclipseContext.class);
        } catch (Exception e) {
            BundleContext bundleContext = getBundle().getBundleContext();
            eclipseContext = EclipseContextFactory.getServiceContext(bundleContext);
        }
        return ContextInjectionFactory.make(clazz, eclipseContext);
    }
}
