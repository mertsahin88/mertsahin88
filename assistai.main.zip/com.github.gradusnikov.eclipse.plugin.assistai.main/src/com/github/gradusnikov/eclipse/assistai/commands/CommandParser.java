package com.github.gradusnikov.eclipse.assistai.commands;

import java.util.*;
import java.util.regex.*;

public class CommandParser {

    public static AssistantCommand parse(String userInput, String editorContent) {
        userInput = userInput.trim().toLowerCase();

        // 1. Syntax Check
        if (userInput.matches(".*(check syntax|syntax check).*")) {
            return new AssistantCommand("syntaxCheckCode", Map.of("code", editorContent, "url", "/source/main"));
        }

        // 2. Pretty Print
        if (userInput.matches(".*pretty print.*|.*format code.*")) {
            return new AssistantCommand("prettyPrinter", Map.of("source", editorContent));
        }

        // 3. Create Transport
        Matcher transportMatcher = Pattern.compile("create transport(?: called| named)?\\s+\"([\\w\\-\\s]+)\"").matcher(userInput);
        if (transportMatcher.find()) {
            return new AssistantCommand("createTransport", Map.of("description", transportMatcher.group(1)));
        }

        // 4. Get Structure
        Matcher structureMatcher = Pattern.compile("get_structure (\\w+)").matcher(userInput);
        if (structureMatcher.find()) {
            return new AssistantCommand("getStructure", Map.of("structure_name", structureMatcher.group(1)));
        }

        // 5. Search Object
        Matcher searchMatcher = Pattern.compile("search (?:for )?(\\w+)").matcher(userInput);
        if (searchMatcher.find()) {
            return new AssistantCommand("searchObject", Map.of("query", searchMatcher.group(1)));
        }

        // 6. Run Unit Test
        Matcher testMatcher = Pattern.compile("(run|start)? ?unit tests? (?:on|for)? (\\w+)").matcher(userInput);
        if (testMatcher.find()) {
            return new AssistantCommand("unitTestRun", Map.of("object", testMatcher.group(2)));
        }

        // 7. Create ABAP Object
        Matcher createObjMatcher = Pattern.compile("create (\\w+) named (\\w+) in package (\\w+) using transport (\\w+)").matcher(userInput);
        if (createObjMatcher.find()) {
            return new AssistantCommand("createObject", Map.of(
                    "type", createObjMatcher.group(1),
                    "name", createObjMatcher.group(2),
                    "package", createObjMatcher.group(3),
                    "transport", createObjMatcher.group(4),
                    "source", editorContent
            ));
        }

        // 8. Set Source
        if (userInput.matches(".*(set source|update source|change code).*")) {
            return new AssistantCommand("setObjectSource", Map.of(
                    "source", editorContent,
                    "uri", "/source/main",
                    "transport", ""
            ));
        }

        // 9. Activate Object
        if (userInput.matches(".*activate.*object.*")) {
            return new AssistantCommand("activateObjects", Map.of("name", "", "type", ""));
        }

        // 10. Usage References
        if (userInput.contains("find usage") || userInput.contains("where is this used")) {
            return new AssistantCommand("usageReferences", Map.of("uri", "/source/main", "line", 1, "column", 1));
        }

        // 11. Find Definition
        if (userInput.contains("find definition") || userInput.contains("go to definition")) {
            return new AssistantCommand("findDefinition", Map.of("uri", "/source/main", "line", 1, "column", 1));
        }

        // 12. Get Object Structure
        Matcher objStructMatcher = Pattern.compile("get object structure for (\\w+)").matcher(userInput);
        if (objStructMatcher.find()) {
            return new AssistantCommand("objectStructure", Map.of("object", objStructMatcher.group(1), "type", ""));
        }

        // 13. Release Transport
        Matcher releaseMatcher = Pattern.compile("release transport (\\w+)").matcher(userInput);
        if (releaseMatcher.find()) {
            return new AssistantCommand("transportRelease", Map.of("transportId", releaseMatcher.group(1)));
        }

        // 14. Evaluate Unit Test Run
        Matcher evalMatcher = Pattern.compile("evaluate test run (\\w+)").matcher(userInput);
        if (evalMatcher.find()) {
            return new AssistantCommand("unitTestEvaluation", Map.of("run_id", evalMatcher.group(1)));
        }

        // Fallback
        return new AssistantCommand("unknown", Map.of("raw", userInput));
    }
}
