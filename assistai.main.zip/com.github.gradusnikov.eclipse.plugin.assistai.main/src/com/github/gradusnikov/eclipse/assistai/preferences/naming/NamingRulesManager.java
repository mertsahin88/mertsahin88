package com.github.gradusnikov.eclipse.assistai.preferences.naming;

import org.eclipse.jface.preference.IPreferenceStore;
import com.github.gradusnikov.eclipse.assistai.Activator;

import java.util.LinkedHashMap;
import java.util.Map;

public class NamingRulesManager {

    private static NamingRulesManager instance;
    private final IPreferenceStore store;

    private static final String PREFIX = "NAMING_RULE_";

    private final String[] objectTypes = new String[] {
        "Class", "Report", "FunctionModule", "Interface", "ExceptionClass",
        "CDS_View", "CDS_ViewEntity", "CDS_ConsumptionView", "CDS_PrivateView", "CDS_ViewExtension",
        "DataElement", "Domain", "DatabaseTable", "Structure", "TableType", "SearchHelp",
        "RAP_Entity", "RAP_Projection", "RAP_Behavior", "RAP_ServiceDef", "RAP_ServiceBind",
        "LocalVariable", "GlobalVariable", "Constant_Local", "Constant_Global", "Structure_Local", "Structure_Global",
        "Table_Local", "Table_Global", "ObjectRef_Local", "ObjectRef_Global", "RangeTable_Local", "RangeTable_Global",
        "Param_Importing", "Param_Exporting", "Param_Changing", "Param_Returning",
        "SmartForm", "AdobeForm", "Dynpro", "WD_Component", "WD_View", "WD_Plug_In", "WD_Plug_Out",
        "BADI_ImplClass", "BADI_EnhSpot", "Enh_Impl", "Project_CMOD",
        "Authorization_Class", "Authorization_Object", "Message_Class", "Transaction_Code", "Lock_Object",
        "Include_TOP", "Include_F01", "Include_I01", "Include_O01", "Module_Pool", "BSP_Application"
    };

    private NamingRulesManager() {
        store = Activator.getDefault().getPreferenceStore();
    }

    public static NamingRulesManager getInstance() {
        if (instance == null) {
            instance = new NamingRulesManager();
        }
        return instance;
    }

    public Map<String, NamingRule> getAllRules() {
        Map<String, NamingRule> rules = new LinkedHashMap<>();
        for (String objectType : objectTypes) {
            String pattern = store.getString(PREFIX + objectType);
            if (pattern != null && !pattern.isEmpty()) {
                rules.put(objectType, new NamingRule(pattern));
            }
        }
        return rules;
    }

    public String getAllRulesAsText() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, NamingRule> entry : getAllRules().entrySet()) {
            sb.append(String.format("- **%s**: %s\n",
                    entry.getKey(),
                    entry.getValue().getPattern()));
        }
        return sb.toString();
    }

    public NamingRule getRuleForObjectType(String objectType) {
        String pattern = store.getString(PREFIX + objectType);
        if (pattern != null && !pattern.isEmpty()) {
            return new NamingRule(pattern);
        }
        return null;
    }
}    