package com.github.gradusnikov.eclipse.assistai.mcp.services;

import com.github.gradusnikov.eclipse.assistai.mcp.ToolExecutor;

import java.util.HashMap;
import java.util.Map;

public class AbapMetadataService {

    public static Object getStructure(String structureName) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("structure_name", structureName);
        return ToolExecutor.getInstance().call("getStructure", payload).join();
    }

    public static Object getTable(String tableName) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("table_name", tableName);
        return ToolExecutor.getInstance().call("getTable", payload).join();
    }

    public static Object getTypeInfo(String typeName) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("type_name", typeName);
        return ToolExecutor.getInstance().call("getTypeInfo", payload).join();
    }

    public static Object getObjectStructure(String objectName, String objectType) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("object", objectName);
        payload.put("type", objectType);
        return ToolExecutor.getInstance().call("objectStructure", payload).join();
    }
}
