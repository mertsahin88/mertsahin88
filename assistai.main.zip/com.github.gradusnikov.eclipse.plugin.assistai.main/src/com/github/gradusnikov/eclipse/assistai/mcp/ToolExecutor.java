package com.github.gradusnikov.eclipse.assistai.mcp;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;

public class ToolExecutor {

    private static ToolExecutor instance;
    private static Object sharedFunctions;

    private final Object functions;

    public ToolExecutor(Object functions) {
        this.functions = functions;
        sharedFunctions = functions;
    }

    public static synchronized ToolExecutor getInstance() {
        if (instance == null) {
            if (sharedFunctions == null) {
                throw new IllegalStateException("ToolExecutor has not been initialized with a functions instance.");
            }
            instance = new ToolExecutor(sharedFunctions);
        }
        return instance;
    }

    public static void initialize(Object functions) {
        sharedFunctions = functions;
        instance = new ToolExecutor(functions);
    }

    public Method[] getFunctions() {
        return Arrays.stream(functions.getClass().getDeclaredMethods())
                .filter(method -> Objects.nonNull(method.getAnnotation(Tool.class)))
                .toArray(Method[]::new);
    }

    public CompletableFuture<Object> call(String name, Map<String, Object> args) {
        // ✅ Check if mcp-abap is connected before proceeding
    	if (!McpClientRetistry.getInstance().isConnected("mcp-abap")) {
            return CompletableFuture.failedFuture(
                new IllegalStateException("MCP-ABAP server is not connected. Go to Preferences > MCP Servers.")
            );
        }

        Method method = getFunctionCallbackByName(name)
            .orElseThrow(() -> new RuntimeException("Tool " + name + " not found!"));

        Object[] argValues = mapArguments(method, args);

        return CompletableFuture.supplyAsync(() -> {
            try {
                return invokeMethod(method, argValues);
            } catch (RuntimeException originalEx) {
                if (isReconnectableError(originalEx)) {
                    try {
                        System.out.println("[ToolExecutor] Reinitializing MCP server after session failure...");
                        functions.getClass().getMethod("initialize").invoke(functions);
                        return invokeMethod(method, argValues); // retry
                    } catch (Exception retryEx) {
                        throw new RuntimeException("Reconnect failed: " + retryEx.getMessage(), retryEx);
                    }
                }
                throw originalEx;
            }
        });
    }

    private Object invokeMethod(Method method, Object[] args) {
        try {
            return method.invoke(functions, args);
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public CompletableFuture<Object> call(String name, String[] args) {
        return call(name, toMap(args));
    }

    public Object[] mapArguments(Method method, Map<String, Object> argMap) {
        return Arrays.stream(method.getParameters())
                .map(ToolExecutor::toParamName)
                .map(argMap::get)
                .toArray();
    }

    public Map<String, Object> toMap(String[] keyVal) {
        if (keyVal.length % 2 != 0) {
            throw new IllegalArgumentException("Not a key-val array");
        }
        var map = new HashMap<String, Object>();
        for (int i = 0; i < keyVal.length; i += 2) {
            map.put(keyVal[i], keyVal[i + 1]);
        }
        return map;
    }

    public Optional<Method> getFunctionCallbackByName(String name) {
        return Arrays.stream(getFunctions())
                .filter(method -> toFunctionName(method).equals(name))
                .findFirst();
    }

    public static String toParamName(Parameter parameter) {
        return Optional.ofNullable(parameter.getAnnotation(ToolParam.class))
                .map(ToolParam::name)
                .filter(Predicate.not(String::isBlank))
                .orElse(parameter.getName());
    }

    public static String toFunctionName(Method method) {
        return Optional.ofNullable(method.getAnnotation(Tool.class))
                .map(Tool::name)
                .filter(Predicate.not(String::isBlank))
                .orElse(method.getName());
    }

    private boolean isReconnectableError(Throwable e) {
        String msg = e.getMessage() != null ? e.getMessage().toLowerCase() : "";
        return msg.contains("session expired") ||
               msg.contains("unauthorized") ||
               msg.contains("closed") ||
               msg.contains("connection reset");
    }
}
