package com.github.gradusnikov.eclipse.assistai.commands;

import java.util.Map;

public class AssistantCommand {

    private final String toolName;
    private final Map<String, Object> parameters;

    public AssistantCommand(String toolName, Map<String, Object> parameters) {
        this.toolName = toolName;
        this.parameters = parameters;
    }

    public String getToolName() {
        return toolName;
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }
}