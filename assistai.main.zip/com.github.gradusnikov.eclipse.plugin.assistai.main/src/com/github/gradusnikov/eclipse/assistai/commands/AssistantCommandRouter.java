package com.github.gradusnikov.eclipse.assistai.commands;

import com.github.gradusnikov.eclipse.assistai.mcp.services.*;
import com.github.gradusnikov.eclipse.assistai.mcp.McpClientRetistry;

public class AssistantCommandRouter {

    public static Object route(AssistantCommand command) {
        if (!McpClientRetistry.getInstance().isConnected("mcp-abap")) {
            return "✘ MCP-ABAP server not connected. Go to Preferences > MCP Servers and provide SAP credentials.";
        }

        try {
            return switch (command.getToolName()) {
                case "createObject" -> AbapObjectCreateService.createAndActivate(
                        (String) command.getParameters().get("type"),
                        (String) command.getParameters().get("name"),
                        (String) command.getParameters().get("source"),
                        (String) command.getParameters().get("package"),
                        (String) command.getParameters().get("transport")
                );
                case "setObjectSource" -> AbapObjectCreateService.setSource(
                        (String) command.getParameters().get("source"),
                        (String) command.getParameters().get("uri"),
                        (String) command.getParameters().get("lockHandle"),
                        (String) command.getParameters().get("transport")
                );
                case "activateObjects" -> AbapObjectCreateService.activate(
                        (String) command.getParameters().get("name"),
                        (String) command.getParameters().get("type")
                );
                case "syntaxCheckCode" -> AbapCodeAnalysisService.syntaxCheck(
                        (String) command.getParameters().get("code"),
                        (String) command.getParameters().get("url")
                );
                case "prettyPrinter" -> AbapCodeAnalysisService.prettyPrint(
                        (String) command.getParameters().get("source")
                );
                case "searchObject" -> AbapSearchService.searchObject(
                        (String) command.getParameters().get("query")
                );
                case "getStructure" -> AbapMetadataService.getStructure(
                        (String) command.getParameters().get("structure_name")
                );
                case "objectStructure" -> AbapMetadataService.getObjectStructure(
                        (String) command.getParameters().get("object"),
                        (String) command.getParameters().get("type")
                );
                case "findDefinition" -> AbapCodeAnalysisService.findDefinition(
                        (String) command.getParameters().get("uri"),
                        (int) command.getParameters().get("line"),
                        (int) command.getParameters().get("column")
                );
                case "usageReferences" -> AbapCodeAnalysisService.usageReferences(
                        (String) command.getParameters().get("uri"),
                        (int) command.getParameters().get("line"),
                        (int) command.getParameters().get("column")
                );
                case "unitTestRun" -> AbapUnitTestService.runTests(
                        (String) command.getParameters().get("object")
                );
                case "unitTestEvaluation" -> AbapUnitTestService.evaluateTests(
                        (String) command.getParameters().get("run_id")
                );
                case "createTransport" -> AbapTransportService.createTransport(
                        (String) command.getParameters().get("description")
                );
                case "transportRelease" -> AbapTransportService.releaseTransport(
                        (String) command.getParameters().get("transportNumber")
                );
                default -> "✘ Unknown assistant command: " + command.getToolName();
            };
        } catch (Exception e) {
            e.printStackTrace();
            return "✘ Error executing command: " + e.getMessage();
        }
    }
}
