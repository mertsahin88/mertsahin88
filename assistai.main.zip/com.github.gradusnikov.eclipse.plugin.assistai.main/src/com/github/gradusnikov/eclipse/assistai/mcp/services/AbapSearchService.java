package com.github.gradusnikov.eclipse.assistai.mcp.services;

import com.github.gradusnikov.eclipse.assistai.mcp.ToolExecutor;

import java.util.HashMap;
import java.util.Map;

public class AbapSearchService {

    public static Object searchObject(String query) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("query", query);
        return ToolExecutor.getInstance().call("searchObject", payload).join();
    }

    public static Object findObjectPath(String objectName, String objectType) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("object", objectName);
        payload.put("type", objectType);
        return ToolExecutor.getInstance().call("findObjectPath", payload).join();
    }
}
