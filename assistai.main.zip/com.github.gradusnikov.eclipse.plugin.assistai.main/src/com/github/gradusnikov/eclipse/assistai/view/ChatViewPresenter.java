package com.github.gradusnikov.eclipse.assistai.view;

import static com.github.gradusnikov.eclipse.assistai.tools.ImageUtilities.createPreview;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.jobs.IJobManager;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.e4.core.di.annotations.Creatable;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.WizardNewFileCreationPage;

import com.github.gradusnikov.eclipse.assistai.Activator;
import com.github.gradusnikov.eclipse.assistai.chat.Attachment;
import com.github.gradusnikov.eclipse.assistai.chat.ChatMessage;
import com.github.gradusnikov.eclipse.assistai.chat.Conversation;
import com.github.gradusnikov.eclipse.assistai.chat.Attachment.FileContentAttachment;
import com.github.gradusnikov.eclipse.assistai.jobs.AssistAIJobConstants;
import com.github.gradusnikov.eclipse.assistai.jobs.SendConversationJob;
import com.github.gradusnikov.eclipse.assistai.mcp.services.CodeEditingService;
import com.github.gradusnikov.eclipse.assistai.network.subscribers.AppendMessageToViewSubscriber;
import com.github.gradusnikov.eclipse.assistai.prompt.ChatMessageFactory;
import com.github.gradusnikov.eclipse.assistai.prompt.ChatMessageUtilities;
import com.github.gradusnikov.eclipse.assistai.prompt.Prompts;
import com.github.gradusnikov.eclipse.assistai.repository.ModelApiDescriptorRepository;
import com.github.gradusnikov.eclipse.assistai.tools.ResourceUtilities;
import com.github.gradusnikov.eclipse.assistai.tools.AbapObjectDetector;
import com.github.gradusnikov.eclipse.assistai.tools.AbapObjectDetector.AbapObjectMetadata;
import com.github.gradusnikov.eclipse.assistai.mcp.services.AbapObjectCreateService;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;


import jakarta.annotation.PostConstruct;
import jakarta.inject.Inject;
import jakarta.inject.Provider;
import jakarta.inject.Singleton;

@Creatable
@Singleton
public class ChatViewPresenter {
	@Inject
	private ILog logger;

	@Inject
	private PartAccessor partAccessor;

	@Inject
	private Conversation conversation;

	@Inject
	private ChatMessageFactory chatMessageFactory;

	@Inject
	private IJobManager jobManager;

	@Inject
	private Provider<SendConversationJob> sendConversationJobProvider;

	@Inject
	private AppendMessageToViewSubscriber appendMessageToViewSubscriber;

	@Inject
	private ApplyPatchWizardHelper applyPatchWizzardHelper;

	@Inject
	private CodeEditingService codeEditingService;

	@Inject
	private ModelApiDescriptorRepository modelReposotiry;

	private IPreferenceStore preferences;

	private static final String LAST_SELECTED_DIR_KEY = "lastSelectedDirectory";

	private final List<Attachment> attachments = new ArrayList<>();

	@PostConstruct
	public void init() {
		preferences = Activator.getDefault().getPreferenceStore();
		appendMessageToViewSubscriber.setPresenter(this);

		initializeAvailableModels();
	}

	private void initializeAvailableModels() {
		// Initialize model from preferences if available
		var selectedModel = modelReposotiry.getModelInUse();
		var models = modelReposotiry.listModelApiDescriptors();
		applyToView(view -> {
			view.setAvailableModels(models, Optional.ofNullable(selectedModel.uid()).orElse(""));
		});
	}

	public void onClear() {
		onStop();
		conversation.clear();
		attachments.clear();
		applyToView(view -> {
			view.clearChatView();
			view.clearUserInput();
			view.clearAttachments();
		});
	}

	public void onSendUserMessage(String text) {
		ChatMessage message = createUserMessage(text);
		conversation.add(message);
		applyToView(part -> {
			part.clearUserInput();
			part.clearAttachments();
			part.appendMessage(message.getId(), message.getRole());
			String content = ChatMessageUtilities.toMarkdownContent(message);
			part.setMessageHtml(message.getId(), content);
			attachments.clear();
		});
		sendConversationJobProvider.get().schedule();
	}

	private ChatMessage createUserMessage(String userMessage) {
		ChatMessage message = chatMessageFactory.createUserChatMessage(() -> userMessage);
		message.setAttachments(attachments);
		return message;
	}

	public ChatMessage beginFunctionCallMessage() {
		ChatMessage message = chatMessageFactory.createAssistantChatMessage("");
		// DO NOT ADD IT TO CONVERSATION
		applyToView(messageView -> {
			messageView.appendMessage(message.getId(), message.getRole());
			messageView.setInputEnabled(false);
		});
		return message;
	}

	public ChatMessage beginMessageFromAssistant() {
		ChatMessage message = chatMessageFactory.createAssistantChatMessage("");
		conversation.add(message);
		applyToView(messageView -> {
			messageView.appendMessage(message.getId(), message.getRole());
			messageView.setInputEnabled(false);
		});
		return message;
	}

	public void updateMessageFromAssistant(ChatMessage message) {
		applyToView(messageView -> {
			messageView.setMessageHtml(message.getId(), message.getContent());
		});
	}

	public void endMessageFromAssistant(ChatMessage message) {
		applyToView(messageView -> {
			messageView.setInputEnabled(true);
			if (message.getContent().isBlank()) {
				conversation.removeLastMessage();
				messageView.removeMessage(message.getId());
			}
		});
	}

	public void hideMessage(String messageId) {
		applyToView(messageView -> {
			messageView.hideMessage(messageId);
		});
	}

	/**
	 * Cancels all running ChatGPT jobs
	 */
	public void onStop() {
		var jobs = jobManager.find(null);
		Arrays.stream(jobs).filter(job -> job.getName().startsWith(AssistAIJobConstants.JOB_PREFIX))
				.forEach(Job::cancel);

		applyToView(messageView -> {
			messageView.setInputEnabled(true);
		});
	}

	/**
	 * Copies the given code block to the system clipboard.
	 *
	 * @param codeBlock The code block to be copied to the clipboard.
	 */
	public void onCopyCode(String codeBlock) {
		var clipboard = new Clipboard(PlatformUI.getWorkbench().getDisplay());
		var textTransfer = TextTransfer.getInstance();
		clipboard.setContents(new Object[] { codeBlock }, new Transfer[] { textTransfer });
		clipboard.dispose();
	}

	public void onApplyPatch(String codeBlock) {
		applyPatchWizzardHelper.showApplyPatchWizardDialog(codeBlock, null);

	}

	public void onSendPredefinedPrompt(Prompts type, ChatMessage message) {
		conversation.add(message);

		// update view
		applyToView(messageView -> {
			messageView.appendMessage(message.getId(), message.getRole());
			messageView.setMessageHtml(message.getId(), type.getDescription());
		});

		// schedule message
		sendConversationJobProvider.get().schedule();
	}

	public void onAddAttachment() {
		Display display = PlatformUI.getWorkbench().getDisplay();
		if (Objects.isNull(display)) {
			logger.error("No active display");
			return;
		}

		display.asyncExec(() -> {
			FileDialog fileDialog = new FileDialog(display.getActiveShell(), SWT.OPEN);
			fileDialog.setText("Select an Image");

			// Retrieve the last selected directory from the preferences
			String lastSelectedDirectory = preferences.getString(LAST_SELECTED_DIR_KEY);
			fileDialog.setFilterPath(lastSelectedDirectory);

			fileDialog.setFilterExtensions(new String[] { "*.png", "*.jpeg", "*.jpg" });
			fileDialog.setFilterNames(new String[] { "PNG files (*.png)", "JPEG files (*.jpeg, *.jpg)" });

			String selectedFilePath = fileDialog.open();

			if (selectedFilePath != null) {
				// Save the last selected directory back to the preferences
				String newLastSelectedDirectory = new File(selectedFilePath).getParent();
				preferences.putValue(LAST_SELECTED_DIR_KEY, newLastSelectedDirectory);

				ImageData[] imageDataArray = new ImageLoader().load(selectedFilePath);
				if (imageDataArray.length > 0) {
					attachments
							.add(new Attachment.ImageAttachment(imageDataArray[0], createPreview(imageDataArray[0])));
					applyToView(messageView -> {
						messageView.setAttachments(attachments);
					});
				}
			}
		});
	}

	public void applyToView(Consumer<? super ChatView> consumer) {
		partAccessor.findMessageView().ifPresent(consumer);
	}

	public void onImageSelected(Image image) {
		System.out.println("selected");
	}

	public void onAttachmentAdded(ImageData imageData) {
		attachments.add(new Attachment.ImageAttachment(imageData, createPreview(imageData)));
		applyToView(messageView -> {
			messageView.setAttachments(attachments);
		});
	}

	public void onAttachmentAdded(FileContentAttachment attachment) {
		attachments.add(attachment);
		applyToView(messageView -> {
			messageView.setAttachments(attachments);
		});
	}

	public void onInsertCode(String codeBlock) {
		Display.getDefault().asyncExec(() -> {
			try {
				Optional.ofNullable(PlatformUI.getWorkbench()).map(workbench -> workbench.getActiveWorkbenchWindow())
						.map(window -> window.getActivePage()).map(page -> page.getActiveEditor())
						.flatMap(editor -> Optional
								.ofNullable(editor.getAdapter(org.eclipse.ui.texteditor.ITextEditor.class)))
						.ifPresent(textEditor -> {
							var selectionProvider = textEditor.getSelectionProvider();
							var document = textEditor.getDocumentProvider().getDocument(textEditor.getEditorInput());

							if (selectionProvider != null && document != null) {
								var selection = (org.eclipse.jface.text.ITextSelection) selectionProvider
										.getSelection();
								try {
									// Replace selection or insert at cursor position
									if (selection.getLength() > 0) {
										// Replace selected text
										document.replace(selection.getOffset(), selection.getLength(), codeBlock);
									} else {
										// Insert at cursor position
										document.replace(selection.getOffset(), 0, codeBlock);
									}
								} catch (org.eclipse.jface.text.BadLocationException e) {
									logger.error("Error inserting code at location", e);
								}
							} else {
								logger.error("Selection provider or document is null");
							}
						});
			} catch (Exception e) {
				logger.error("Error inserting code", e);
			}
		});
	}

	public void onDiffCode(String codeBlock) {
		Display.getDefault().asyncExec(() -> {
			try {
				Optional.ofNullable(PlatformUI.getWorkbench()).map(workbench -> workbench.getActiveWorkbenchWindow())
						.map(window -> window.getActivePage()).map(page -> page.getActiveEditor())
						.flatMap(editor -> Optional
								.ofNullable(editor.getAdapter(org.eclipse.ui.texteditor.ITextEditor.class)))
						.ifPresent(textEditor -> {
							// Get the file information
							if (textEditor.getEditorInput() instanceof org.eclipse.ui.part.FileEditorInput) {
								org.eclipse.ui.part.FileEditorInput fileInput = (org.eclipse.ui.part.FileEditorInput) textEditor
										.getEditorInput();

								// Get project name and file path
								String projectName = fileInput.getFile().getProject().getName();
								String filePath = fileInput.getFile().getProjectRelativePath().toString();

								// Generate diff using the CodeEditingService
								String diff = codeEditingService.generateCodeDiff(projectName, filePath, codeBlock, 3 // Default
																														// context
																														// lines
								);

								if (diff != null && !diff.isBlank()) {
									// Show the apply patch wizard with the generated diff and preselected project
									applyPatchWizzardHelper.showApplyPatchWizardDialog(diff, projectName);
								} else {
									logger.info("No differences found between current code and provided code block");
								}
							} else {
								logger.error("Cannot get file information from editor");
							}
						});
			} catch (Exception e) {
				logger.error("Error generating diff for code", e);
			}
		});
	}

    public void onNewFile(String codeBlock, String lang) {
        if (lang == null || !lang.equalsIgnoreCase("abap")) {
            System.out.println("[AssistAI] Skipping non-ABAP content for new file.");
            return;
        }

        AbapObjectMetadata metadata = AbapObjectDetector.extractMetadata(codeBlock);
        System.out.println("[AssistAI] Detected ABAP object: " + metadata.objectType + " → " + metadata.objectName);

        // Ask user for package and transport request
        Display.getDefault().syncExec(() -> {
            InputDialog pkgDialog = new InputDialog(null, "Enter Package", "Package for object:", "ZLOCAL", null);
            if (pkgDialog.open() != Window.OK) return;
            String packageName = pkgDialog.getValue();

            InputDialog trDialog = new InputDialog(null, "Enter Transport Request", "Transport number:", "", null);
            if (trDialog.open() != Window.OK) return;
            String transport = trDialog.getValue();

            boolean success = AbapObjectCreateService.createAndActivate(
                    metadata.objectType,
                    metadata.objectName,
                    metadata.sourceCode,
                    packageName,
                    transport
            );

            if (success) {
                System.out.println("[AssistAI] Object created and activated successfully.");
            } else {
                System.err.println("[AssistAI] Object creation failed.");
            }
        });
    }

	/**
	 * Handles model selection from the dropdown menu.
	 * 
	 * This method is called when a user selects a different AI model from the
	 * dropdown menu in the UI. It updates the preferences to store the selected
	 * model and would typically update any service configurations to use the new
	 * model.
	 * 
	 * @param modelId The ID of the selected model
	 */
	public void onModelSelected(String modelId) {
		logger.info("Model selected: " + modelId);

		modelReposotiry.setModelInUse(modelId);
		initializeAvailableModels();

//        ChatMessage message = chatMessageFactory.createAssistantChatMessage(
//                "Model changed to **" + modelInUse.modelName() + "**. New messages will use this model.");
//        
//        partAccessor.findMessageView().ifPresent(messageView -> {
//            messageView.appendMessage(message.getId(), message.getRole());
//            messageView.setMessageHtml(message.getId(), message.getContent());
//            
//            // Auto-hide this message after a few seconds
//            Display.getDefault().timerExec(5000, () -> {
//                messageView.removeMessage(message.getId());
//            });
//        });
	}

	/**
	 * Regenerates the last AI response using the currently selected model.
	 * 
	 * This method is called when the user clicks the replay button. It removes the
	 * last assistant message from the conversation (if it exists) and sends the
	 * conversation again to generate a new response.
	 */
	public void onReplayLastMessage() {
		logger.info("Replaying last message with current model");

		// Check if there's a conversation with at least one message
		if (conversation.messages().isEmpty()) {
			return;
		}
		// If the last message is from the assistant, remove it
		// (We want to regenerate the assistant's response)
		List<ChatMessage> messages = conversation.messages();
		if (!messages.isEmpty() && "assistant".equals(messages.get(messages.size() - 1).getRole())) {
			ChatMessage lastMessage = messages.get(messages.size() - 1);
			conversation.removeLastMessage();

			// Remove the message from the UI
			applyToView(view -> {
				view.removeMessage(lastMessage.getId());
			});
		}
		// Send the conversation for processing to generate a new response
		sendConversationJobProvider.get().schedule();
	}

	public void onViewVisible() {
		initializeAvailableModels();
	}
}
