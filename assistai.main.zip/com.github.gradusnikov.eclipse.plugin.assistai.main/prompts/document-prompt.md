<context>
${currentFileContent}
${selectedContent}
</context>

In the context of the provided ABAP file, generate or update the ABAP Doc comment for the selected element. Follow these guidelines:

1. Output only the ABAP Doc comment. Do **not** include the method, class, or attribute declarations.
2. Use the ABAP Doc syntax (lines starting with "!) and include relevant tags such as @parameter, @return, or @raising.
3. Ensure the documentation is concise, meaningful, and reflects the actual behavior and purpose of the code.
4. If ABAP Doc already exists for the selected item, revise it to match the current implementation.

Example format for ABAP Doc:

```abap
"! Calculates the final invoice amount.
"!
"! @parameter iv_net_amount | Net amount before tax
"! @parameter iv_tax_rate   | Applicable tax rate (e.g. 0.19)
"! @return                  | Final amount after applying tax
"! @raising cx_invalid_data | If input values are inconsistent
```