<context>
${currentFileContent}
${selectedContent}
</context>

Analyze the ABAP code provided in the context and generate a local ABAP Unit test class. If a unit test class already exists, append new test methods to it. Follow the structure and naming conventions of existing test methods where applicable.

Strictly follow all of the following rules:
- If only selected content is present, generate tests *only* for that portion (e.g., a single method or FORM routine).
- Use CLASS ... DEFINITION FOR TESTING and CLASS ... IMPLEMENTATION placed at the end of the main class.
- Use cl_abap_unit_assert methods such as assert_equals, assert_not_initial, assert_initial, assert_subrc, fail, or similar — avoid generic ASSERT statements.
- Keep each test method focused on a single behavior. One method = one test case.
- Name test methods clearly and within 30 characters. Prefer descriptive names like `test_calc_with_valid_input`.
- Always include a setup method to initialize the CUT (class under test) and any required data. Add TEARDOWN only if needed.
- If input variations are needed, simulate parameterized tests using LOOP AT with test case structures or ranges.
- Prefer mocking or dependency injection if external components (like HTTP calls, destinations, etc.) are involved. Use TEST-SEAM, test doubles, or subclass    redefinition techniques when possible.
- Do not include explanations or comments. Only return the complete test class code block.