package com.github.gradusnikov.eclipse.assistai.preferences.naming;

import org.eclipse.jface.preference.IPreferenceStore;
import com.github.gradusnikov.eclipse.assistai.Activator;

public class NamingStandardsPreferencePresenter {

    private final IPreferenceStore store;
    private static final String PREFIX = "NAMING_RULE_";

    public NamingStandardsPreferencePresenter() {
        this.store = Activator.getDefault().getPreferenceStore();
    }

    public String getRule(String objectType) {
        return store.getString(PREFIX + objectType);
    }

    public void setRule(String objectType, String pattern) {
        store.setValue(PREFIX + objectType, pattern);
    }

    public void resetRule(String objectType) {
        store.setToDefault(PREFIX + objectType);
    }
}    