package com.github.gradusnikov.eclipse.assistai.preferences.naming;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.github.gradusnikov.eclipse.assistai.Activator;

public class NamingStandardsPreferencePage extends PreferencePage implements IWorkbenchPreferencePage {

    private NamingStandardsPreferencePresenter presenter;
    private List objectTypeList;
    private Text ruleText;
    private Button namingRuleCheckToggle;

    private final String[] objectTypes = new String[]{
        "Class", "Report", "FunctionModule", "Interface", "ExceptionClass",
        "CDS_View", "CDS_ViewEntity", "CDS_ConsumptionView", "CDS_PrivateView", "CDS_ViewExtension",
        "DataElement", "Domain", "DatabaseTable", "Structure", "TableType", "SearchHelp",
        "RAP_Entity", "RAP_Projection", "RAP_Behavior", "RAP_ServiceDef", "RAP_ServiceBind",
        "LocalVariable", "GlobalVariable", "Constant_Local", "Constant_Global", "Structure_Local", "Structure_Global",
        "Table_Local", "Table_Global", "ObjectRef_Local", "ObjectRef_Global", "RangeTable_Local", "RangeTable_Global",
        "Param_Importing", "Param_Exporting", "Param_Changing", "Param_Returning",
        "SmartForm", "AdobeForm", "Dynpro", "WD_Component", "WD_View", "WD_Plug_In", "WD_Plug_Out",
        "BADI_ImplClass", "BADI_EnhSpot", "Enh_Impl", "Project_CMOD",
        "Authorization_Class", "Authorization_Object", "Message_Class", "Transaction_Code", "Lock_Object",
        "Include_TOP", "Include_F01", "Include_I01", "Include_O01", "Module_Pool", "BSP_Application"
    };

    @Override
    public void init(IWorkbench workbench) {
        setPreferenceStore(Activator.getDefault().getPreferenceStore());
        setDescription("Edit SAP ABAP naming standards per object type.");
        presenter = new NamingStandardsPreferencePresenter();
    }

    @Override
    protected Control createContents(Composite parent) {
        Composite container = new Composite(parent, SWT.NONE);
        container.setLayout(new GridLayout(1, false));

        namingRuleCheckToggle = new Button(container, SWT.CHECK);
        namingRuleCheckToggle.setText("Apply naming rules during Code Review");
        namingRuleCheckToggle.setSelection(getPreferenceStore().getBoolean("assistai.naming.check.enabled"));

        SashForm sashForm = new SashForm(container, SWT.VERTICAL);
        sashForm.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

        Composite listWrapper = new Composite(sashForm, SWT.NONE);
        listWrapper.setLayout(new GridLayout(1, false));

        objectTypeList = new List(listWrapper, SWT.BORDER | SWT.SINGLE | SWT.V_SCROLL);
        objectTypeList.setItems(objectTypes);
        GridData listLayoutData = new GridData(SWT.FILL, SWT.TOP, true, false);
        listLayoutData.heightHint = objectTypeList.getItemHeight() * 8;
        objectTypeList.setLayoutData(listLayoutData);

        Composite editorWrapper = new Composite(sashForm, SWT.NONE);
        editorWrapper.setLayout(new GridLayout(1, false));

        Label ruleLabel = new Label(editorWrapper, SWT.NONE);
        ruleLabel.setText("Naming Rule Pattern:");

        ruleText = new Text(editorWrapper, SWT.BORDER | SWT.MULTI | SWT.V_SCROLL | SWT.WRAP);
        ruleText.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

        sashForm.setWeights(new int[]{20, 80});

        objectTypeList.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                int index = objectTypeList.getSelectionIndex();
                if (index >= 0) {
                    String objectType = objectTypes[index];
                    ruleText.setText(presenter.getRule(objectType));
                }
            }
        });

        ruleText.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                int index = objectTypeList.getSelectionIndex();
                if (index >= 0) {
                    presenter.setRule(objectTypes[index], ruleText.getText());
                }
            }
        });

        return container;
    }

    @Override
    protected void performDefaults() {
        namingRuleCheckToggle.setSelection(false);
        for (String objectType : objectTypes) {
            presenter.resetRule(objectType);
        }
        if (objectTypeList.getSelectionIndex() != -1) {
            ruleText.setText(presenter.getRule(objectTypes[objectTypeList.getSelectionIndex()]));
        }
        super.performDefaults();
    }

    @Override
    public boolean performOk() {
        getPreferenceStore().setValue("assistai.naming.check.enabled", namingRuleCheckToggle.getSelection());
        return super.performOk();
    }
}
