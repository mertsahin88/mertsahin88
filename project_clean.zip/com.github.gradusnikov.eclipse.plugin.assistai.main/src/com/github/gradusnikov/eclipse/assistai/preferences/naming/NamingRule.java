package com.github.gradusnikov.eclipse.assistai.preferences.naming;

public class NamingRule {
    private final String pattern;

    public NamingRule(String pattern) {
        this.pattern = pattern;
    }

    public String getPattern() {
        return pattern;
    }
}
