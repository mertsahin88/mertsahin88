package com.github.gradusnikov.eclipse.assistai.preferences;

import java.util.Map;

/**
 * Constant definitions for plug-in preferences
 */
public class PreferenceConstants
{
    public static final String ASSISTAI_CONNECTION_TIMEOUT_SECONDS = "AssistAIConnectionTimeoutSeconds";
    public static final String ASSISTAI_REQUEST_TIMEOUT_SECONDS = "AssistAIRequestTimeoutSeconds";
    public static final String ASSISTAI_SELECTED_MODEL = "AssistaAISelectedModel";
    public static final String ASSISTAI_DEFINED_MODELS = "AssistAIDefinedModels";

    // MCP Server preferences
    public static final String ASSISTAI_DEFINED_MCP_SERVERS = "AssistAIDefinedMCPServers";
    public static final String ASSISTAI_SELECTED_MCP_SERVER = "AssistAISelectedMCPServer";

    // Naming rule check toggle
    public static final String ENABLE_NAMING_CHECK = "assistai.naming.check.enabled";

}
