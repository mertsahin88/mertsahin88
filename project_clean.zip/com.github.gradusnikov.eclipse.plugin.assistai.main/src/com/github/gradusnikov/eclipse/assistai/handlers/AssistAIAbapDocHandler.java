package com.github.gradusnikov.eclipse.assistai.handlers;

import com.github.gradusnikov.eclipse.assistai.prompt.Prompts;

public class AssistAIAbapDocHandler extends AssistAIHandlerTemplate
{
    public AssistAIAbapDocHandler()
    {
        super( Prompts.DOCUMENT );
    }
}
