<context>
${gitDiff}
</context>

Process the Git patch and create a meaningful and detailed Git commit comment.

Follow these guidelines:
1. The length of the line of the Git commit comment cannot be longer than 72 characters
2. Return commit comment as a code block type `txt`.