<context>
${currentFileContent}
${selectedContent}
</context>


Provide refactored version of the selected code in the ${currentFileName}.

If the code does not require refactoring - respond with the message "The code does not require refactoring". 

Keep explanation concise and compact.

Don't print the content of the whole class. Just the modified snippet code, and the referenced methods.



